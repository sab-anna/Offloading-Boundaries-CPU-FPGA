// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xmicrobench.h"

extern XMicrobench_Config XMicrobench_ConfigTable[];

#ifdef SDT
XMicrobench_Config *XMicrobench_LookupConfig(UINTPTR BaseAddress) {
	XMicrobench_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XMicrobench_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XMicrobench_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XMicrobench_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMicrobench_Initialize(XMicrobench *InstancePtr, UINTPTR BaseAddress) {
	XMicrobench_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMicrobench_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMicrobench_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XMicrobench_Config *XMicrobench_LookupConfig(u16 DeviceId) {
	XMicrobench_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMICROBENCH_NUM_INSTANCES; Index++) {
		if (XMicrobench_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMicrobench_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMicrobench_Initialize(XMicrobench *InstancePtr, u16 DeviceId) {
	XMicrobench_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMicrobench_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMicrobench_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

