// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMICROBENCH_H
#define XMICROBENCH_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmicrobench_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XMicrobench_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XMicrobench;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMicrobench_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMicrobench_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMicrobench_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMicrobench_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XMicrobench_Initialize(XMicrobench *InstancePtr, UINTPTR BaseAddress);
XMicrobench_Config* XMicrobench_LookupConfig(UINTPTR BaseAddress);
#else
int XMicrobench_Initialize(XMicrobench *InstancePtr, u16 DeviceId);
XMicrobench_Config* XMicrobench_LookupConfig(u16 DeviceId);
#endif
int XMicrobench_CfgInitialize(XMicrobench *InstancePtr, XMicrobench_Config *ConfigPtr);
#else
int XMicrobench_Initialize(XMicrobench *InstancePtr, const char* InstanceName);
int XMicrobench_Release(XMicrobench *InstancePtr);
#endif

void XMicrobench_Start(XMicrobench *InstancePtr);
u32 XMicrobench_IsDone(XMicrobench *InstancePtr);
u32 XMicrobench_IsIdle(XMicrobench *InstancePtr);
u32 XMicrobench_IsReady(XMicrobench *InstancePtr);
void XMicrobench_EnableAutoRestart(XMicrobench *InstancePtr);
void XMicrobench_DisableAutoRestart(XMicrobench *InstancePtr);

void XMicrobench_Set_in_r(XMicrobench *InstancePtr, u64 Data);
u64 XMicrobench_Get_in_r(XMicrobench *InstancePtr);
void XMicrobench_Set_out_r(XMicrobench *InstancePtr, u64 Data);
u64 XMicrobench_Get_out_r(XMicrobench *InstancePtr);
void XMicrobench_Set_n(XMicrobench *InstancePtr, u32 Data);
u32 XMicrobench_Get_n(XMicrobench *InstancePtr);
void XMicrobench_Set_k(XMicrobench *InstancePtr, u32 Data);
u32 XMicrobench_Get_k(XMicrobench *InstancePtr);

void XMicrobench_InterruptGlobalEnable(XMicrobench *InstancePtr);
void XMicrobench_InterruptGlobalDisable(XMicrobench *InstancePtr);
void XMicrobench_InterruptEnable(XMicrobench *InstancePtr, u32 Mask);
void XMicrobench_InterruptDisable(XMicrobench *InstancePtr, u32 Mask);
void XMicrobench_InterruptClear(XMicrobench *InstancePtr, u32 Mask);
u32 XMicrobench_InterruptGetEnabled(XMicrobench *InstancePtr);
u32 XMicrobench_InterruptGetStatus(XMicrobench *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
