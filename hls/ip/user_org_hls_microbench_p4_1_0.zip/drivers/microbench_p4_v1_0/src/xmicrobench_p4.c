// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmicrobench_p4.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMicrobench_p4_CfgInitialize(XMicrobench_p4 *InstancePtr, XMicrobench_p4_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMicrobench_p4_Start(XMicrobench_p4 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMicrobench_p4_IsDone(XMicrobench_p4 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMicrobench_p4_IsIdle(XMicrobench_p4 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMicrobench_p4_IsReady(XMicrobench_p4 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMicrobench_p4_EnableAutoRestart(XMicrobench_p4 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMicrobench_p4_DisableAutoRestart(XMicrobench_p4 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_AP_CTRL, 0);
}

void XMicrobench_p4_Set_in_r(XMicrobench_p4 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_IN_R_DATA, (u32)(Data));
    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_IN_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMicrobench_p4_Get_in_r(XMicrobench_p4 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_IN_R_DATA);
    Data += (u64)XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_IN_R_DATA + 4) << 32;
    return Data;
}

void XMicrobench_p4_Set_out_r(XMicrobench_p4 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_OUT_R_DATA, (u32)(Data));
    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_OUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMicrobench_p4_Get_out_r(XMicrobench_p4 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_OUT_R_DATA);
    Data += (u64)XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_OUT_R_DATA + 4) << 32;
    return Data;
}

void XMicrobench_p4_Set_n(XMicrobench_p4 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_N_DATA, Data);
}

u32 XMicrobench_p4_Get_n(XMicrobench_p4 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_N_DATA);
    return Data;
}

void XMicrobench_p4_Set_k(XMicrobench_p4 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_K_DATA, Data);
}

u32 XMicrobench_p4_Get_k(XMicrobench_p4 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_K_DATA);
    return Data;
}

void XMicrobench_p4_InterruptGlobalEnable(XMicrobench_p4 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_GIE, 1);
}

void XMicrobench_p4_InterruptGlobalDisable(XMicrobench_p4 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_GIE, 0);
}

void XMicrobench_p4_InterruptEnable(XMicrobench_p4 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_IER);
    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_IER, Register | Mask);
}

void XMicrobench_p4_InterruptDisable(XMicrobench_p4 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_IER);
    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMicrobench_p4_InterruptClear(XMicrobench_p4 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_p4_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_ISR, Mask);
}

u32 XMicrobench_p4_InterruptGetEnabled(XMicrobench_p4 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_IER);
}

u32 XMicrobench_p4_InterruptGetStatus(XMicrobench_p4 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMicrobench_p4_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_P4_CONTROL_ADDR_ISR);
}

