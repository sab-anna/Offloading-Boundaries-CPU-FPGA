// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMICROBENCH_P4_H
#define XMICROBENCH_P4_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmicrobench_p4_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XMicrobench_p4_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XMicrobench_p4;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMicrobench_p4_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMicrobench_p4_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMicrobench_p4_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMicrobench_p4_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XMicrobench_p4_Initialize(XMicrobench_p4 *InstancePtr, UINTPTR BaseAddress);
XMicrobench_p4_Config* XMicrobench_p4_LookupConfig(UINTPTR BaseAddress);
#else
int XMicrobench_p4_Initialize(XMicrobench_p4 *InstancePtr, u16 DeviceId);
XMicrobench_p4_Config* XMicrobench_p4_LookupConfig(u16 DeviceId);
#endif
int XMicrobench_p4_CfgInitialize(XMicrobench_p4 *InstancePtr, XMicrobench_p4_Config *ConfigPtr);
#else
int XMicrobench_p4_Initialize(XMicrobench_p4 *InstancePtr, const char* InstanceName);
int XMicrobench_p4_Release(XMicrobench_p4 *InstancePtr);
#endif

void XMicrobench_p4_Start(XMicrobench_p4 *InstancePtr);
u32 XMicrobench_p4_IsDone(XMicrobench_p4 *InstancePtr);
u32 XMicrobench_p4_IsIdle(XMicrobench_p4 *InstancePtr);
u32 XMicrobench_p4_IsReady(XMicrobench_p4 *InstancePtr);
void XMicrobench_p4_EnableAutoRestart(XMicrobench_p4 *InstancePtr);
void XMicrobench_p4_DisableAutoRestart(XMicrobench_p4 *InstancePtr);

void XMicrobench_p4_Set_in_r(XMicrobench_p4 *InstancePtr, u64 Data);
u64 XMicrobench_p4_Get_in_r(XMicrobench_p4 *InstancePtr);
void XMicrobench_p4_Set_out_r(XMicrobench_p4 *InstancePtr, u64 Data);
u64 XMicrobench_p4_Get_out_r(XMicrobench_p4 *InstancePtr);
void XMicrobench_p4_Set_n(XMicrobench_p4 *InstancePtr, u32 Data);
u32 XMicrobench_p4_Get_n(XMicrobench_p4 *InstancePtr);
void XMicrobench_p4_Set_k(XMicrobench_p4 *InstancePtr, u32 Data);
u32 XMicrobench_p4_Get_k(XMicrobench_p4 *InstancePtr);

void XMicrobench_p4_InterruptGlobalEnable(XMicrobench_p4 *InstancePtr);
void XMicrobench_p4_InterruptGlobalDisable(XMicrobench_p4 *InstancePtr);
void XMicrobench_p4_InterruptEnable(XMicrobench_p4 *InstancePtr, u32 Mask);
void XMicrobench_p4_InterruptDisable(XMicrobench_p4 *InstancePtr, u32 Mask);
void XMicrobench_p4_InterruptClear(XMicrobench_p4 *InstancePtr, u32 Mask);
u32 XMicrobench_p4_InterruptGetEnabled(XMicrobench_p4 *InstancePtr);
u32 XMicrobench_p4_InterruptGetStatus(XMicrobench_p4 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
