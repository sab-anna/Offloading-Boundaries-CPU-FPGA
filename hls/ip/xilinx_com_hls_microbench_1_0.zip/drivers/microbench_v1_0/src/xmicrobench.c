// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmicrobench.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMicrobench_CfgInitialize(XMicrobench *InstancePtr, XMicrobench_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMicrobench_Start(XMicrobench *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMicrobench_IsDone(XMicrobench *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMicrobench_IsIdle(XMicrobench *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMicrobench_IsReady(XMicrobench *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMicrobench_EnableAutoRestart(XMicrobench *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMicrobench_DisableAutoRestart(XMicrobench *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_AP_CTRL, 0);
}

void XMicrobench_Set_in_r(XMicrobench *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_IN_R_DATA, (u32)(Data));
    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_IN_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMicrobench_Get_in_r(XMicrobench *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_IN_R_DATA);
    Data += (u64)XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_IN_R_DATA + 4) << 32;
    return Data;
}

void XMicrobench_Set_out_r(XMicrobench *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_OUT_R_DATA, (u32)(Data));
    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_OUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMicrobench_Get_out_r(XMicrobench *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_OUT_R_DATA);
    Data += (u64)XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_OUT_R_DATA + 4) << 32;
    return Data;
}

void XMicrobench_Set_n(XMicrobench *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_N_DATA, Data);
}

u32 XMicrobench_Get_n(XMicrobench *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_N_DATA);
    return Data;
}

void XMicrobench_Set_k(XMicrobench *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_K_DATA, Data);
}

u32 XMicrobench_Get_k(XMicrobench *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_K_DATA);
    return Data;
}

void XMicrobench_InterruptGlobalEnable(XMicrobench *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_GIE, 1);
}

void XMicrobench_InterruptGlobalDisable(XMicrobench *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_GIE, 0);
}

void XMicrobench_InterruptEnable(XMicrobench *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_IER);
    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_IER, Register | Mask);
}

void XMicrobench_InterruptDisable(XMicrobench *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_IER);
    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMicrobench_InterruptClear(XMicrobench *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMicrobench_WriteReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_ISR, Mask);
}

u32 XMicrobench_InterruptGetEnabled(XMicrobench *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_IER);
}

u32 XMicrobench_InterruptGetStatus(XMicrobench *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMicrobench_ReadReg(InstancePtr->Control_BaseAddress, XMICROBENCH_CONTROL_ADDR_ISR);
}

